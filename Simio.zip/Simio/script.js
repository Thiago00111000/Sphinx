const console = document.querySelector("#console");
let text = "macaco";

function simia(length){
    let result = '';
    let characters = "acmo"
    let charactersleng = characters.length;
    let counter = 0; 
    while (counter < length){
        result += characters.charAt(Math.floor(Math.random()*charactersleng));
        counter += 1;
    }
    if (result == text){
        alert("O macaco terminou seu trabalho, obrigado pela paciência:)")
    }
    let gimkol = `<p>${result}</p>`;
    console.insertAdjacentHTML("afterend", gimkol);
    return result;
}

const loop = () => {
    simia(6)

    loopId = setTimeout(() => {
        loop()
    }, 500); 
}
 
loop()

//ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz1234567890!@#$%¨&*()
//The monkey finished his work, thank's for your patience:)